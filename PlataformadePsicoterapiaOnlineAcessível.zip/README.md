# Wireframes para o site "Integra Psicoterapia"

Este diretório contém os wireframes para as principais páginas do site "Integra Psicoterapia".

Os wireframes serão criados usando HTML e CSS para facilitar a visualização e posterior implementação.
